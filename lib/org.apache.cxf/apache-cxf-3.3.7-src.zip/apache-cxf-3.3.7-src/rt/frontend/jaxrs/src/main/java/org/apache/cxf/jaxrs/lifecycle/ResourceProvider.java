/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.cxf.jaxrs.lifecycle;

import org.apache.cxf.message.Message;

/**
 * ResourceProvider controls the life-cycle of the JAX-RS root resources.
 */
public interface ResourceProvider {

    /**
     * Returns the resource instance which will handle the current request
     * @param m the current request message
     * @return resource instance
     */
    Object getInstance(Message m);

    /**
     * Releases the resource instance if needed
     * @param m the current request message
     * @param o resource instance
     */
    void releaseInstance(Message m, Object o);

    /**
     * Returns the Class of the resource
     * @return
     */
    Class<?> getResourceClass();

    /**
     * Indicates if the managed resource is a singleton
     * @return
     */
    boolean isSingleton();
}
