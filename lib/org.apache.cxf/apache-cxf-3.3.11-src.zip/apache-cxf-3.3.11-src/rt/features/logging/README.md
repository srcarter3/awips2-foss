# CXF Message logging

See [Userguide - Message Logging](http://cxf.apache.org/docs/message-logging.html)

## Tests

* JAX-WS: org.apache.cxf.jaxws.logging.SOAPLoggingTest
* JAX-RS: tbd

