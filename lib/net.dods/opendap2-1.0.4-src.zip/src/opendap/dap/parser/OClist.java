package opendap.dap.parser;

import java.util.Vector;

public class OClist extends Vector<Object>
{
    public void pop() {remove(size()-1);}
}
