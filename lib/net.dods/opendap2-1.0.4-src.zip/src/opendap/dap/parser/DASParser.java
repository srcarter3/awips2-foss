package opendap.dap.parser;

import java.io.InputStream;

public class DASParser extends DapParser
{
    public DASParser(InputStream stream)
	throws ParseException
    {
	  super(stream);
    }

}
